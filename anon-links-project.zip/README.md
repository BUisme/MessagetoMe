
# Anonymous Links (Frontend + Backend)

โปรเจกต์นี้ประกอบด้วย 2 ส่วน:

- `frontend/` เว็บไซต์ static สำหรับ
  - ผู้สร้างลิงก์: สร้างลิงก์, ตั้งชื่อเรื่อง, ตั้งเวลาเปิด/ปิดการตอบกลับ, ดูข้อความที่มีคนส่งมา
  - ผู้ตอบ: ฝากข้อความแบบไม่ระบุตัวตน + ใส่ช่องทางติดต่อ (IG / FB / Line)
- `backend/` เซิร์ฟเวอร์ Node.js (Express) สำหรับเก็บลิงก์และข้อความ

## ฟีเจอร์ตามที่ขอ

1. สร้างลิงก์รับคำตอบแบบไม่ระบุตัวตน  
2. ผู้ตอบสามารถทิ้งช่องทางติดต่อได้ (IG / FB / Line)  
3. ผู้สร้างลิงก์ตั้งชื่อเรื่องได้  
4. มีแค่ผู้สร้างลิงก์ (ที่ถือ viewToken) เท่านั้นที่ดูข้อความได้  
5. ส่วน frontend สามารถรันบน GitHub Pages ได้ (เป็น static files)  
6. ตั้งเวลาเริ่มรับ / หยุดรับข้อความของแต่ละลิงก์ได้ (ตรวจสอบฝั่ง backend)

---

## วิธีใช้ Backend (Node.js)

```bash
cd backend
npm install
npm start
```

เซิร์ฟเวอร์จะรันที่ `http://localhost:3000`

- สร้างลิงก์ใหม่: `POST /api/links` body: `{ title, startAt, endAt }`
- ส่งข้อความ: `POST /api/links/:id/replies` body: `{ text, contacts }`
- ดูข้อความ: `GET /api/links/:id/replies` (ต้องส่ง header `x-view-token` = viewToken ของลิงก์นั้น)

ข้อมูลจะถูกเก็บในไฟล์ `data.json` (อย่างง่าย)

---

## วิธีใช้ Frontend (GitHub Pages ก็ได้)

1. เปิดไฟล์ `frontend/app.js`  
   แก้บรรทัดด้านบนสุด:

   ```js
   const API_BASE = "http://localhost:3000"; // หรือ URL backend ที่ deploy ไว้
   ```

2. ทดสอบแบบ local (ง่ายสุด):  

   เปิดโฟลเดอร์ `frontend/` แล้วใช้ live server ง่าย ๆ เช่น:

   ```bash
   # ถ้ามี Python
   cd frontend
   python -m http.server 4173
   ```

   จากนั้นเปิดเบราว์เซอร์ที่ `http://localhost:4173`

3. ถ้าจะรันบน GitHub Pages:  

   - สร้าง repo ใหม่ใน GitHub  
   - อัปโหลดไฟล์ในโฟลเดอร์ `frontend/` ทั้งหมดเข้า repo  
   - เปิด GitHub Pages ให้ชี้ไปที่ branch (เช่น `main`) และโฟลเดอร์ root  
   - ตั้งค่า `API_BASE` ใน `app.js` ให้เป็น URL ของ backend ที่ deploy จริง (เช่น Vercel / Render / Railway / VPS ของตัวเอง)

---

## การทำงานโดยสรุป

- ฝั่งผู้สร้าง
  - เข้าเว็บ (frontend) → กด "สร้างลิงก์ใหม่"
  - ตั้งชื่อเรื่อง + เวลาเริ่ม/จบ → frontend เรียก `POST /api/links`
  - backend สร้าง `id` และ `viewToken` ส่งกลับมา
  - frontend เก็บข้อมูลนี้ไว้ใน `localStorage` ของเบราว์เซอร์ผู้สร้าง
  - ผู้สร้างกด "ดูข้อความ" → frontend ส่ง `GET /api/links/:id/replies` พร้อม header `x-view-token` = viewToken
- ฝั่งผู้ตอบ
  - ใช้ลิงก์ที่ผู้สร้างแชร์มา เช่น `https://your-page.github.io/?id=ABCD1234`
  - หน้าเว็บจะขึ้นฟอร์ม "ฝากข้อความ" → กรอกข้อความ + IG/FB/Line (ถ้ามี)
  - frontend ส่ง `POST /api/links/:id/replies` ไป backend
  - backend ตรวจเวลาว่าอยู่ในช่วงที่รับได้หรือไม่ แล้วค่อยบันทึก

---

ถ้าอยากให้ผมช่วยปรับโค้ดเพิ่ม (เช่น เปลี่ยน UI, เพิ่ม password ของผู้สร้าง, หรือ deploy บน Vercel/Render แบบละเอียด) บอกได้เลย 🙂
